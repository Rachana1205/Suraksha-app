package com.example.registration;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class ContactActivity extends AppCompatActivity {
ImageView addc;
TextView text;
private static final int CONTACT_PERMISSION_CODE=1;
    private static final int CONTACT_PICK_CODE=2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact);
        text=(TextView)findViewById(R.id.text);
        addc=(ImageView)findViewById(R.id.addc);
        addc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(checkPermission()){
                    pickContact();
                }
                else{
                    requestPermission();
                }
            }
        });
    }
    private boolean checkPermission(){
        boolean result= ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS)==(PackageManager.PERMISSION_GRANTED);
        return result;
    }
    private void requestPermission(){
        String permission=(Manifest.permission.READ_CONTACTS);
        ActivityCompat.requestPermissions(this, new String[]{permission},CONTACT_PERMISSION_CODE);
    }
    private void pickContact(){
        Intent intent=new Intent(Intent.ACTION_PICK, ContactsContract.Contacts.CONTENT_URI);
        startActivityForResult(intent,CONTACT_PICK_CODE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CONTACT_PERMISSION_CODE && grantResults.length < 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            pickContact();
        }
        /*else{
                Toast.makeText(this, "Permission Denied", Toast.LENGTH_SHORT).show();
        }*/
    }
        protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode==RESULT_OK){
            if(requestCode==CONTACT_PICK_CODE){
                //text.setText("");
                Cursor cursor1,cursor2;
                Uri uri = data.getData();
                cursor1=this.getContentResolver().query(uri,null,null,null,null);
                if(cursor1.moveToFirst()){
                    @SuppressLint("Range") String contactid =cursor1.getString(cursor1.getColumnIndex(ContactsContract.Contacts._ID));
                    @SuppressLint("Range") String contactName =cursor1.getString(cursor1.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME));
                    @SuppressLint("Range") String idResults =cursor1.getString(cursor1.getColumnIndex(ContactsContract.Contacts.HAS_PHONE_NUMBER));
                    int idResultHold= Integer.parseInt(idResults);
                    text.append("\nID: "+contactid);
                    text.append("\nName: "+contactName);
                    if(idResultHold==1){
                        cursor2=getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,null,ContactsContract.CommonDataKinds.Phone.CONTACT_ID+" = "+contactid,null,null);
                        while(cursor2.moveToNext()){
                            @SuppressLint("Range") String contactNumber=cursor2.getString(cursor2.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));

                            text.append("\nPhone: "+contactNumber+"\n");

                        }
                        cursor2.close();
                    }
                    cursor1.close();
                }
            }
        }
    }
}